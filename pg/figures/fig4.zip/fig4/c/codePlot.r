library("ggplot2")
library("Cairo")
library(compiler)
enableJIT(3)
options(bitmapType='cairo')
snp <- data.frame(values=c(0.1473153, 0.0575117, 0.1627572),cat=c("cis", "trans", "total"),group=c("SNP","SNP","SNP"))
indel <- data.frame(values=c(0.1277996, 0.05077647, 0.1390363),cat=c("cis", "trans", "total"),group=c("INDEL","INDEL","INDEL"))
orf <- data.frame(values=c(0.01812918, 0.002341785, 0.02020086),cat=c("cis", "trans", "total"),group=c("ORF","ORF","ORF"))
all <-  data.frame(values=c(0.1513295, 0.07168151, 0.1708634), cat=c("cis", "trans", "total"),group=c("all","all","all"))
data <- rbind(snp, indel)
data <- rbind(data, orf)
data <- rbind(data, all)
data$cat <- factor(data$cat, levels = c("cis", "trans", "total"))
plot = ggplot(data, aes(x=group, y=values, group=cat, fill=cat)) + 
    geom_bar( stat="identity", position="dodge")+labs( y="explained variance", x="", color="", fill="", title="") +theme_bw() +theme_grey(base_size = 32) + theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(fill=NA, color="black", size=1, linetype="solid"),
    panel.background = element_blank(),
    legend.direction = 'horizontal', 
    legend.position = c(0.3,0.95),
    axis.text = element_text(colour = "black"))
pdf("cisTrans.pdf", width=9, height=9)
plot
dev.off()
png("cisTrans.png",width=600,height=600)
plot
dev.off()


