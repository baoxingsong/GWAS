library("ggplot2")
library("Cairo")
library(compiler)
enableJIT(3)
options(bitmapType='cairo')

data <- read.table("TableForPlotFromMixedModelResult")
data <- data[which(data$V8>0.001),]


data$color="bug"
list <- which(data$V2<0)
data[list,]$V2=0
list <- which(data$V5<data$V2)
data[list,]$V5=data[list,]$V2
list <- which(data$V8<data$V5)
data[list,]$V8=data[list,]$V5

data[which(data$V2>0 & data$V5==data$V2 & data$V8==data$V5 ),]$color = "S"
data[which(data$V2==0 & data$V5 > data$V2 & data$V8 == data$V5 ),]$color = "I"
data[which(data$V8 > data$V5 & data$V5==0 ),]$color = "O"
data[which(data$V5 > data$V2 & data$V2>0 & data$V8==data$V5 ),]$color = "SI"
data[which(data$V8 > data$V5 & data$V5 == data$V2 & data$V2>0),]$color = "SO"
data[which(data$V2==0 & data$V5>0 & data$V8 > data$V5),]$color = "IO"
data[which(data$V2>0 & data$V8 > data$V5 & data$V5 > data$V2 ),]$color = "SIO"
data[which(data$color == "bug"),]



data$color <- factor(data$color,levels = c("S", "I", "O", "SI", "SO", "IO", "SIO"))
summary(data$color)

#I   IO    O    S   SI  SIO   SO 
# 572    3   12 8340 1503   21   57


p <- ggplot(data=data, aes(x=color, y=(V8-V2), color=color))+geom_boxplot(outlier.colour="#FFFFFF")+geom_point(position = position_jitter(width = 0.25), alpha=0.4, size=3.2) +
        labs( y="extra variance explained", x="", color="", fill="", title="") +
        theme_bw() +theme_grey(base_size = 32) + ylim(-0.03, 0.22) + 
        annotate("text", x = 1, y = -0.02, label = paste("n=", length(which(data$color=="S")),sep=""), cex=6)+
        annotate("text", x = 2, y = -0.02, label = paste("n=", length(which(data$color=="I")),sep=""), cex=6)+
        annotate("text", x = 3, y = -0.02, label = paste("n=", length(which(data$color=="O")),sep=""), cex=6)+
        annotate("text", x = 4, y = -0.02, label = paste("n=", length(which(data$color=="SI")),sep=""), cex=6)+
        annotate("text", x = 5, y = -0.02, label = paste("n=", length(which(data$color=="SO")),sep=""), cex=6)+
        annotate("text", x = 6, y = -0.02, label = paste("n=", length(which(data$color=="IO")),sep=""), cex=6)+
        annotate("text", x = 7, y = -0.02, label = paste("n=", length(which(data$color=="SIO")),sep=""), cex=6)+
        theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "none",
    legend.key.size=unit(2.2, 'lines'),
    panel.border = element_rect(fill=NA, color="black", size=1, linetype="solid"),

        panel.background = element_blank(),
        axis.text=element_text(colour="black"))


pdf("eqtlExplained.pdf", width=9, height=9)
p
dev.off()

png("eqtlExplained.png",width=600,height=600)
p
dev.off()


