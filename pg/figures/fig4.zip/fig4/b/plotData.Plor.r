library(ggplot2)
library("Cairo")
library(grid)
library(compiler)
enableJIT(3)
options(bitmapType='cairo')

dataall <- read.table("plotData")



data=dataall
data$V2 = as.character( data$V2 )
data[which(data$V2=="ORF"),]$V2="ORFS"
data$V2 = as.factor( data$V2 )
data$V3 <- factor(data$V3, levels=c("Chr5","Chr4", "Chr3", "Chr2", "Chr1"))

plot <- ggplot()+geom_point(data=data, aes(x=V6, y=V4, group=V2, color=V2), alpha=0.4)+
    facet_grid(V3~V5, scales="free", space="free", switch="both")+labs(x="variant position", y="gene position", title="")+
  theme_bw() +theme_grey(base_size = 50) + theme(
  	legend.title=element_blank(),
  	axis.line = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"),
    panel.background = element_blank(),
    axis.text=element_blank(),
  	axis.ticks=element_blank(),
  	legend.position = "top",
  	strip.background =  element_blank(),
    panel.spacing=unit(0,"lines"),
    legend.key.size=unit(3.2, 'lines'))


pdf("all.pdf", width=15, height=15)
plot
dev.off()

png("all.png", width=1000, height=1000)
plot
dev.off()


data = dataall[which(dataall$V2 =="ORF"),]
data$V3 <- factor(data$V3, levels=c("Chr5","Chr4", "Chr3", "Chr2", "Chr1"))
plot <- ggplot()+geom_point(data=data, aes(x=V6, y=V4),color="blue")+facet_grid(V3~V5, scales="free", space="free", switch="both")+labs(x="ORFS position", y="gene position", title="")+
  theme_bw() +theme_grey(base_size = 32) + theme(
  	axis.line = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"),
    panel.background = element_blank(),
    axis.text=element_blank(),
    axis.ticks=element_blank(),
    strip.background =  element_blank(),
    panel.spacing=unit(0, "lines"))

pdf("orf.pdf", width=9, height=9)
plot
dev.off()

png("orf.png", width=600, height=600)
plot
dev.off()


data = dataall[which(dataall$V2 =="SNP"),]
data$V3 <- factor(data$V3, levels=c("Chr5","Chr4", "Chr3", "Chr2", "Chr1"))
plot <- ggplot()+geom_point(data=data, aes(x=V6, y=V4),color="blue")+facet_grid(V3~V5, scales="free", space="free", switch="both")+labs(x="SNP position", y="gene position", title="")+
  theme_bw() +theme_grey(base_size = 32) + theme(
  	axis.line = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"),
    panel.background = element_blank(),
    axis.text=element_blank(),
  	axis.ticks=element_blank(),
    strip.background =  element_blank(),
    panel.spacing=unit(0, "lines"))

pdf("snp.pdf", width=9, height=9)
plot
dev.off()

png("snp.png", width=600, height=600)
plot
dev.off()


data = dataall[which(dataall$V2 =="INDEL"),]
data$V3 <- factor(data$V3, levels=c("Chr5","Chr4", "Chr3", "Chr2", "Chr1"))
plot <- ggplot()+geom_point(data=data, aes(x=V6, y=V4),color="blue")+facet_grid(V3~V5, scales="free", space="free", switch="both")+labs(x="INDEL position", y="gene position", title="")+
  theme_bw() +theme_grey(base_size = 32) + theme(
  	axis.line = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"),
    panel.background = element_blank(),
    axis.text=element_blank(),
 axis.ticks=element_blank(),
    strip.background =  element_blank(),
    panel.spacing=unit(0, "lines"))

pdf("indel.pdf", width=9, height=9)
plot
dev.off()

png("indel.png", width=600, height=600)
plot
dev.off()
