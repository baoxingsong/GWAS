#exon
#	exonic	notExonic	exonicSig	sigNotExonic
#SNP:  1240294	2629668	245785	393494
#INDEL: 194726	1767610	35390	164466

data <- matrix(c(1240294, 2629668, 245785, 393494), nrow=2)
fisher.test(data)

data <- matrix(c(194726, 1767610, 35390, 164466), nrow=2)
fisher.test(data)



library(compiler)
library(compiler)
enableJIT(3)
library(ggplot2)
library("Cairo")
options(bitmapType='cairo')
label.df <- data.frame(group = c("SNP", "INDEL"), values = c(0.67, 0.26))
df1 <- data.frame(a = c(0.75, 0.75,1.25,1.25), b = c(0.64, 0.66, 0.66, 0.64))
df2 <- data.frame(a = c(1.75, 1.75,2.25,2.25), b = c(0.23, 0.25, 0.25, 0.23))

snp <- data.frame(values=c(1240294/2629668, 245785/393494),cat=c("exon/outside_exon", "sig_exon/sig_outside_exon"),group=c("SNP","SNP"))
indel <- data.frame(values=c(194726/1767610, 35390/164466),cat=c("exon/outside_exon", "sig_exon/sig_outside_exon"),group=c("INDEL","INDEL"))
data <- rbind(snp, indel)
data$cat <- factor(data$cat, levels = c("exon/outside_exon", "sig_exon/sig_outside_exon"))
plot = ggplot(data, aes(x=group, y=values)) + geom_bar( aes(fill=cat), stat="identity", position="dodge")+labs( y="ratio", x="", color="", fill="", title="") + geom_line(data = df1, aes(x = a, y = b))+ geom_line(data = df2, aes(x = a, y = b))+ylim(0,0.85)+ geom_text(data = label.df, label = "***", size=12) + theme_bw() +theme_grey(base_size = 30)+ theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(fill=NA, color="black", size=1, linetype="solid"),
    panel.background = element_blank(),
    legend.direction = 'horizontal',
    legend.position = 'top',
    axis.text = element_text(colour = "black"))
pdf("ratio.pdf", width=9, height=9)
plot
dev.off()
png("ratio.png",width=600,height=600)
plot
dev.off()


