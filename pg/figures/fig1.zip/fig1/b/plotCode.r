library("ggplot2")
library("Cairo")

flyData <- read.table("fruitfly2")
athData <- read.table("ath2")
mean(1-flyData$V7/flyData$V5)
#0.03527117
mean(1-flyData$V10/flyData$V8)
#0.3629973
mean(1-athData$V7/athData$V5)
#0.02399369
mean(1-athData$V10/athData$V8)
#0.3942799


flyData$changedPercent=(1-flyData$V7/flyData$V5)
athData$changedPercent=(1-athData$V7/athData$V5)
flyData$changedPercent2=(1-flyData$V10/flyData$V8)
athData$changedPercent2=(1-athData$V10/athData$V8)


plot <- ggplot()+geom_density(data=flyData, aes(x=changedPercent, fill="D. melanogaster SNP", y = (..count..)/sum(..count..)),alpha = 9/10)+
geom_density(data=athData, aes(x=changedPercent, fill="A. thaliana SNP", y = (..count..)/sum(..count..)),alpha = 9/10)+ 
geom_density(data=flyData, aes(x=changedPercent2, fill="D. melanogaster INDEL", y = (..count..)/sum(..count..)),alpha = 9/10)+ 
geom_density(data=athData, aes(x=changedPercent2, fill="A. thaliana INDEL", y = (..count..)/sum(..count..)),alpha = 9/10)+ 
scale_y_continuous(labels=scales::percent)+
labs(x="proportion of variants under effect", y="frequency density", fill="", title="")+
theme_bw()+theme_grey(base_size = 25) +theme(
	axis.line = element_line(color = "black", size=0.5),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank())+
	theme(legend.position = c(.7, .8),
	panel.border = element_rect(fill=NA, color="black", size=0.5, linetype="solid") )

CairoPDF("plot.pdf", width=9, height=9)
plot
dev.off()
CairoPNG("plot.png",width=600,height=600)
plot
dev.off()


