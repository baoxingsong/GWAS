
outputFile <- "indel_Chr5_23344"


m <- read.table(file = "matrix", row.names = 1, head=T)
library("LDheatmap")
m <- as.matrix(m)
for( i in 1:(sqrt(length(m))-1) ){
	for( j in 1:sqrt(length(m))){
		if( i > j){
			m[i,j] <- m[j,i]
		}
	}
}


	# removedNumberBeforeFirst = 0
	# removedNumberBeforeLast = 0
	# changed=0
	# toRemove = c()
	# for( i in 1: sqrt(length(m)) ){
	# 	ifeveryNa <- 0
	# 	for( j in 1 : sqrt(length(m)) ){
	# 		if( is.na(m[i,j]) ){
				
	# 		}else{
	# 			ifeveryNa=ifeveryNa+1
	# 		}
	# 	}
	# 	if( ifeveryNa <= 1 ){
	# 		if( i <= firstHaplotype ){
	# 			removedNumberBeforeFirst = removedNumberBeforeFirst + 1
	# 		}
	# 		if( i <= lastHaplotype ){
	# 			removedNumberBeforeLast = removedNumberBeforeLast + 1
	# 		}
	# 		toRemove=c(toRemove,-i)
	# 		changed=1
	# 	}
	# }
	# if( 1==changed ){
	# 	m<- m[toRemove,]
	# 	m<- m[,toRemove]
	# }
	# print(changed)
	
	# firstHaplotype = firstHaplotype - removedNumberBeforeFirst
	# lastHaplotype = lastHaplotype - removedNumberBeforeLast
number = which(rownames(m) == outputFile)

pdf(file=paste(outputFile, ".pdf", sep=""), width=12, height=12)
myheatMap <- LDheatmap(m, SNP.name=row.names(m), flip=T, distances="physical", title="", color=colorRampPalette(c("red", "yellow","green"))( 100 ))
LDheatmap.highlight(myheatMap, number-1, number+1, col="blue", lwd=3)
#LDheatmap.highlight(myheatMap, i = firstHaplotype, j=lastHaplotype, col = "black" )
dev.off()
