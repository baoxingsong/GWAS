library(compiler)
enableJIT(3)
library(ggplot2)
library("Cairo")

snp <- read.table("snp_emmax_abn.ps")
colnames(snp) <- c("id", "beta", "pvalue")
snpmarkers <- read.table("snp.map")
colnames(snpmarkers) <- c("chr", "id", "zero", "position")
snp<- merge(x=snp, y=snpmarkers, by="id")
snp <- snp[(order(snp$pvalue)),]
snp$chr <- paste("Chr", snp$chr, sep="")

indel <- read.table("indel3_song_emmax_abn.ps")
indel = indel[,-4]
colnames(indel) <- c("id", "beta", "pvalue")
indelmarkers <- read.table("indel.map")
colnames(indelmarkers) <- c("chr", "id", "zero", "position")
indel <- merge(x=indel, y=indelmarkers, by="id")
indel <- indel[(order(indel$pvalue)),]
indel$chr <- paste("Chr", indel$chr, sep="")

snp <- snp[(order(snp$pvalue)),]
indel <- indel[(order(indel$pvalue)),]

snp = snp[which(snp$chr == "Chr5"),]
snp = snp[which(snp$position > 1024518),]
snp = snp[which(snp$position < 1026500),]

indel = indel[which(indel$chr == "Chr5"),]
indel = indel[which(indel$position > 1024518),]
indel = indel[which(indel$position < 1026500),]


permutation_threshold = 7.7796380204548

ymax=8.5

plot = ggplot()+
    geom_point(data=snp, aes(x=position, y=-log10(pvalue), color="SNP"))+
    geom_point(data=indel, aes(x=position, y=-log10(pvalue), color="INDEL"))+
	labs(x="", y="-log10(pvalue)", title="") + ylim(0, ymax) + xlim(1024518, 1026500)+
    geom_hline(aes(yintercept=permutation_threshold), color="red")+ #total number of variants PM
	theme_bw() +theme_grey(base_size = 36) + scale_fill_discrete("") +
    theme(
    axis.line = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(colour = "black", fill=NA, size=1),
    legend.position="top",
    legend.title=element_blank(),
    legend.direction="horizontal",
    panel.background = element_blank(),
    axis.text.y = element_text( colour = "black"),
	axis.text.x = element_text(angle=300, hjust=0, vjust=1, colour = "black"))



png("tfl1_mahm.png", width=900, height=450)
plot
dev.off()

pdf("tfl1_mahm.pdf", width=10.5, height=7)
plot
dev.off()
