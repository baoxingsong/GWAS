

#R_code

genotype <- read.table("indel_Chr5_23344.ped")
phenotype <- read.table("originalPhenotype")
data <- merge(genotype, phenotype, by ="V1")
data = data[which(data$V7!=0),]

data[which(data$V7==1),]$V7="reference"
data[which(data$V7==2),]$V7="alternative"

library("ggplot2")
p = ggplot(data=data, aes(x=V7, y=V3.y, group=V7))+geom_boxplot(aes(color=V7)) + geom_point(position=position_jitter(width=0.25), aes(V7, V3.y, color=V7 )) + theme_bw()+theme_grey(base_size = 25) +labs(x="genotype",  y="phenotype")+ theme(
	panel.border = element_rect(colour = "black", fill=NA,size=1),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
	legend.text=element_text(size=22),
	strip.background = element_blank(),
    panel.background = element_blank(),
	strip.text.x=element_text(angle=0,hjust=0, vjust=0),
	axis.text.x=element_text(color="black"),
	axis.text.y=element_text(color="black"),
	legend.position = "none")

png("phenotype.png",width=600,height=400)
print(p)
dev.off()
pdf(file="phenotype.pdf", width=9, height=6)
print(p)
dev.off()



