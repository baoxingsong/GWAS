library(ggplot2)
library("Cairo")

data <- read.table("table1")
data2 <- read.table("table2")
data3 <- read.table("table3")
data4 <- read.table("table4")
data5 <- read.table("table5")
data6 <- read.table("table6")
data7 <- read.table("table7")
data8 <- read.table("table8")
data9 <- read.table("table9")
data10 <- read.table("table10")
data11 <- read.table("table11")

data11 = head(data11[order(data11$V1),],20)

dataFull <- merge(data, data2, by="V1")
colnames(dataFull) <- c("V1", "INDEL", "SNP")
dataFull <- merge(dataFull, data3, by="V1")
colnames(dataFull) <- c("V1", "INDEL", "SNP", "INDELSNP")
dataFull <- merge(dataFull, data4, by="V1")
colnames(dataFull) <- c("V1", "INDEL", "SNP", "INDELSNP", "significantINDEL")
dataFull <- merge(dataFull, data5, by="V1")
colnames(dataFull) <- c("V1", "INDEL", "SNP", "INDELSNP", "significantINDEL", "IsolatedSignificantINDEL")
dataFull <- merge(dataFull, data6, by="V1")
colnames(dataFull) <- c("V1", "INDEL", "SNP", "INDELSNP", "significantINDEL", "IsolatedSignificantINDEL", "significantINDELAround")
dataFull <- merge(dataFull, data7, by="V1")
colnames(dataFull) <- c("V1", "INDEL", "SNP", "INDELSNP", "significantINDEL", "IsolatedSignificantINDEL", "significantINDELAround", "IsolatedSignificantINDELAround")
dataFull <- merge(dataFull, data8, by="V1")
colnames(dataFull) <- c("V1", "INDEL", "SNP", "INDELSNP", "significantINDEL", "IsolatedSignificantINDEL", "significantINDELAround", "IsolatedSignificantINDELAround", "ORF")
dataFull <- merge(dataFull, data9, by="V1")
colnames(dataFull) <- c("V1", "ath_INDEL", "ath_SNP", "INDELSNP", "significantINDEL", "IsolatedSignificantINDEL", "significantINDELAround", "IsolatedSignificantINDELAround", "ath_ORF", "fly_SNP")
dataFull <- merge(dataFull, data10, by="V1")
colnames(dataFull) <- c("V1", "ath_INDEL", "ath_SNP", "ath_INDELSNP", "ath_significantINDEL", "ath_IsolatedSignificantINDEL", "ath_significantINDELAround", "ath_IsolatedSignificantINDELAround", "ath_ORF", "fly_SNP", "fly_INDEL")
dataFull <- merge(dataFull, data11, by="V1")
colnames(dataFull) <- c("distance", "ath_INDEL", "ath_SNP", "ath_INDELSNP", "ath_significantINDEL", "ath_IsolatedSignificantINDEL", "ath_significantINDELAround", "ath_IsolatedSignificantINDELAround", "ath_ORF", "fly_SNP", "fly_INDEL", "fly_significantINDEL")



plot <- ggplot(dataFull)+
	#geom_line(size=1, ,aes(x=distance,y=ath_INDEL, group=1, color="A.th_INDEL"))+
	geom_line(size=1, aes(x=distance,y=ath_SNP, group=1, color="Ath_SNP"))+
	geom_line(size=1, aes(x=distance,y=ath_INDELSNP, group=1, color="A.th_SNP+INDEL"))+
	geom_line(size=1, aes(x=distance,y=ath_significantINDEL, group=1, color="A.th_significantINDEL"),linetype=2)+
#	geom_line(size=1, aes(x=distance,y=ath_IsolatedSignificantINDEL, group=1, color="A.th_IsolatedSignificantINDEL"),linetype=2)+

#	geom_line(size=1, aes(x=distance,y=ath_significantINDELAround, group=1, color="A.th_significantINDEL_around"))+
#	geom_line(size=1, aes(x=distance,y=ath_IsolatedSignificantINDELAround, group=1, color="A.th_IsolatedSignificantINDEL_around"))+
	geom_line(size=1, aes(x=distance,y=ath_ORF, group=1, color="A.th_ORF"))+

	geom_line(size=1, aes(x=distance,y=fly_SNP, group=1, color="D.m_SNP"))+
	geom_line(size=1, aes(x=distance,y=fly_INDEL, group=1, color="D.m_INDEL"))+
#	geom_line(size=1, aes(x=distance,y=fly_significantINDEL, group=1, color="D.m_significantINDEL"))+

	guides(color=guide_legend(title=""))+
	labs(x="", y=expression(average~r^2), fill="", title="")+
	theme_bw() +theme_grey(base_size = 43.8) + theme(axis.line =  element_blank(),
		 panel.border = element_rect(colour = "black", fill=NA, size=1),
		 legend.text=element_text(size=26),
	    panel.grid.major = element_blank(),
	    panel.grid.minor = element_blank(),
	   
	    legend.position=c(0.7,0.65),
	    legend.key.size = unit(2, 'lines'),
	    panel.background = element_blank(),
	    axis.text.y = element_text( colour = "black"),
		axis.text.x = element_text(angle=320, hjust=0, vjust=1, colour = "black"))
	
png("ldDDecay.png", width=1200, height=750)
plot
dev.off()

pdf("ldDDecay.pdf", width=18, height=11.25)
plot
dev.off()



