cat /media/song/raid0/22092016/indel/ldDeecay/snpdensity > snpdensity
cat /media/song/raid0/fly/indel/lddecay/snpdensity | sed 's/^2\t/2R\t/g' | sed 's/^1\t/2L\t/g' | sed 's/^3\t/3L\t/g' | sed 's/^4\t/3R\t/g' | sed 's/^5\t/X\t/g' | sed 's/^6\t/4\t/g' >> snpdensity

cat /media/song/raid0/22092016/indel/ldDeecay/indeldensity > indeldensity
cat /media/song/raid0/fly/indel/lddecay/indeldensity | sed 's/^2\t/2R\t/g' | sed 's/^1\t/2L\t/g' | sed 's/^3\t/3L\t/g' | sed 's/^4\t/3R\t/g' | sed 's/^5\t/X\t/g' | sed 's/^6\t/4\t/g' >> indeldensity


perl ~/Downloads/circos-0.69-3/bin/circos --conf CIRCOS.CONF
