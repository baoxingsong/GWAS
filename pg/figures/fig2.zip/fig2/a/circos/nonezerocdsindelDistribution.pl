#!/usr/bin/perl -w
use strict;


my $windowLength=100000;
my $loopEnd=400;
my %allCDS;
open INPUT, "/biodata/dep_tsiantis/grp_gan/song/gennepredication/noAnnotation/tair10/simple.gff";
while(my $line=<INPUT>){
	chomp($line);
	$line=~s/\r//g;
	if($line=~/^Chr(\d)\tTAIR10\tCDS\t(\d+)\t(\d+)\t\.\t.\t.\t/){
		$allCDS{"$1\t$2\t$3"}=1;
	}
}
close INPUT;









=head
my @names=("bur_0", "can_0", "ct_1", "edi_0", "hi_0", "kn_0", "ler_0", "mt_0", "no_0", "oy_0", "po_0", "rsch_4", "sf_2", "tsu_0", "wil_2", "ws_0", "wu_0", "zu_0");
my %allindel;
my %allDISindel;

my %allindelHist;
my %allDIindelHist;

for my $name(@names){
	chdir "/biodata/dep_tsiantis/grp_gan/song/gennepredication/noAnnotation/$name/";
	open INPUT,"gan_perl_hasIndelRescueTranscriptNames.list";
	while(my $line=<INPUT>){
		chomp($line);
		$line=~s/\r//g;
		$allindel{$line}=1;
	}
	close INPUT;
	open INPUT,"gan_perl_hasUnzero_indel_indeled.list";
	while(my $line=<INPUT>){
		chomp($line);
		$line=~s/\r//g;
		$allDISindel{$line}=1;
	}
	close INPUT;
}
chdir "/biodata/dep_tsiantis/grp_gan/song/gennepredication/noAnnotation/gan_map_circos_indel_location";


while(my ($key, $value)=each %allDISindel){
	if(exists $allGene{$key}){
		my $string = $allGene{$key};
		my @stringA=split(/\s/,$string);
		my $ij=70000;
	
		for(my $i=0; $i<=$loopEnd; $i++){
			my $start = $i * $windowLength;
			my $end = $i * $windowLength + $windowLength;
			if($start <= $stringA[1] &&  $stringA[1] < $end){
				if(1==$stringA[1] && $end>30427671){
					$end=30427671;
				}elsif(2==$stringA[1] && $end>19698289){
					$end=19698289;
				}elsif(3==$stringA[1] && $end>23459830){
					$end=23459830;
				}elsif(4==$stringA[1] && $end>18585056){
					$end=18585056;
				}elsif(5==$stringA[1] && $end>26975502){
					$end=26975502;
				}
				print "$end\n";
				if(exists $allDIindelHist{"at$stringA[0] $start $end"}){
					$allDIindelHist{"at$stringA[0] $start $end"}=$allDIindelHist{"at$stringA[0] $start $end"}+1;
				}else{
					$allDIindelHist{"at$stringA[0] $start $end"}=1;
				}
				$ij=$i;
			}
		}

		for(my $j=0; $j<=$loopEnd; $j++){
			my $start = $j * $windowLength;
			my $end = $j * $windowLength + $windowLength;
			if($start <= $stringA[2] && $stringA[2] < $end){
				if($ij != $j){
					if(1==$stringA[1] && $end>30427671){
						$end=30427671;
					}elsif(2==$stringA[1] && $end>19698289){
						$end=19698289;
					}elsif(3==$stringA[1] && $end>23459830){
						$end=23459830;
					}elsif(4==$stringA[1] && $end>18585056){
						$end=18585056;
					}elsif(5==$stringA[1] && $end>26975502){
						$end=26975502;
					}
					if(exists $allDIindelHist{"at$stringA[0] $start $end"}){
						$allDIindelHist{"at$stringA[0] $start $end"}=$allDIindelHist{"at$stringA[0] $start $end"}+1;
					}else{
						$allDIindelHist{"at$stringA[0] $start $end"}=1;
					}
				}
			}
		}

	}else{
		print "$key\n";
	}
}

while(my ($key, $value)=each %allindel){
	if(exists $allGene{$key}){
		my $string = $allGene{$key};
		my @stringA=split(/\s/,$string);
		my $ij=70000;

		for(my $i=0; $i<=$loopEnd; $i++){
			my $start = $i * $windowLength;
			my $end = $i * $windowLength + $windowLength;
			if($start <= $stringA[1] && $stringA[1] < $end){
				if(1==$stringA[1] && $end>30427671){
					$end=30427671;
				}elsif(2==$stringA[1] && $end>19698289){
					$end=19698289;
				}elsif(3==$stringA[1] && $end>23459830){
					$end=23459830;
				}elsif(4==$stringA[1] && $end>18585056){
					$end=18585056;
				}elsif(5==$stringA[1] && $end>26975502){
					$end=26975502;
				}
				if(exists $allindelHist{"at$stringA[0] $start $end"}){
					$allindelHist{"at$stringA[0] $start $end"}=$allindelHist{"at$stringA[0] $start $end"}+1;
				}else{
					$allindelHist{"at$stringA[0] $start $end"}=1;
				}
				$ij=$i;
			}
		}

		for(my $j=0; $j<=$loopEnd; $j++){
			my $start = $j * $windowLength;
			my $end = $j * $windowLength + $windowLength;
			if($start <= $stringA[2] && $stringA[2] < $end){
				if($ij != $j){
					if(1==$stringA[1] && $end>30427671){
						$end=30427671;
					}elsif(2==$stringA[1] && $end>19698289){
						$end=19698289;
					}elsif(3==$stringA[1] && $end>23459830){
						$end=23459830;
					}elsif(4==$stringA[1] && $end>18585056){
						$end=18585056;
					}elsif(5==$stringA[1] && $end>26975502){
						$end=26975502;
					}
					if(exists $allindelHist{"at$stringA[0] $start $end"}){
						$allindelHist{"at$stringA[0] $start $end"}=$allindelHist{"at$stringA[0] $start $end"}+1;
					}else{
						$allindelHist{"at$stringA[0] $start $end"}=1;
					}
				}
			}
		}
	}else{
		print "$key\n";
	}

}


open OUTPUT, ">h2";
while(my ($key, $value)=each %allDIindelHist){
	print OUTPUT "$key $value\n";
}
close OUTPUT;

open OUTPUT, ">h";
while(my ($key, $value)=each %allindelHist){
	print OUTPUT "$key $value\n";
}
close OUTPUT;


my %allgeneHist;
while(my ($key, $value)=each %allGene){
	my $string = $allGene{$key};
	my @stringA=split(/\s/,$string);
	for(my $i=0; $i<=$loopEnd; $i++){
		my $start = $i * $windowLength;
		my $end = $i * $windowLength + $windowLength;
		if($start <= $stringA[2] && $stringA[2] < $end){
			if(1==$stringA[1] && $end>30427671){
				$end=30427671;
			}elsif(2==$stringA[1] && $end>19698289){
				$end=19698289;
			}elsif(3==$stringA[1] && $end>23459830){
				$end=23459830;
			}elsif(4==$stringA[1] && $end>18585056){
				$end=18585056;
			}elsif(5==$stringA[1] && $end>26975502){
				$end=26975502;
			}
			if(exists $allgeneHist{"at$stringA[0] $start $end"}){
				$allgeneHist{"at$stringA[0] $start $end"}=$allgeneHist{"at$stringA[0] $start $end"}+1;
			}else{
				$allgeneHist{"at$stringA[0] $start $end"}=1;
			}
		}
	}
}
open OUTPUT, ">h3";
while(my ($key, $value)=each %allgeneHist){
	print OUTPUT "$key $value\n";
}
close OUTPUT;
=cut
