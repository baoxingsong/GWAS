Here is all the data used to draw the plot using circos v 0.66.
