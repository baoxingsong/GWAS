library(ggplot2)
library("Cairo")

datata <- read.table("fruitFly.table", head=TRUE)
datata=datata[which(datata$chromosome=="3R" | datata$chromosome=="3L"  |  datata$chromosome=="2R" |  datata$chromosome=="2L" | datata$chromosome=="4" | datata$chromosome=="X" ),]

snRNA <- mean(datata[,"snRNA_indelNo"]/datata[,"snRNA_length"], na.rm=TRUE)
pre_miRNA <- mean(datata[,"pre_miRNA_indelNo"]/datata[,"pre_miRNA_length"], na.rm=TRUE)
gene <- mean(datata[,"gene_indelNo"]/datata[,"gene_length"], na.rm=TRUE)
five_prime_UTR <- mean(datata[,"X5UTR_indelNo"]/datata[,"X5UTR_length"], na.rm=TRUE)
three_prime_UTR <- mean(datata[,"X3UTR_indelNo"]/datata[,"X3UTR_length"], na.rm=TRUE)
tRNA <- mean(datata[,"tRNA_indelNo"]/datata[,"tRNA_length"], na.rm=TRUE)
miRNA <- mean(datata[,"miRNA_indelNo"]/datata[,"miRNA_length"], na.rm=TRUE)
CDS <- mean(datata[,"CDS_indelNo"]/datata[,"CDS_length"], na.rm=TRUE)
snoRNA <- mean(datata[,"snoRNA_indelNo"]/datata[,"snoRNA_length"], na.rm=TRUE)
mRNA <- mean(datata[,"mRNA_indelNo"]/datata[,"mRNA_length"], na.rm=TRUE)
exon <- mean(datata[,"exon_indelNo"]/datata[,"exon_length"], na.rm=TRUE)
chromosome <- mean(datata[,"chromesome_indelNo"]/datata[,"chromesome_length"], na.rm=TRUE)
pseudogene <- mean(datata[,"pseudogene_indelNo"]/datata[,"pseudogene_length"], na.rm=TRUE)
ncRNA <- mean(datata[,"ncRNA_indelNo"]/datata[,"ncRNA_length"], na.rm=TRUE)
intron <- mean((datata[,"mRNA_indelNo"]-datata[,"exon_indelNo"])/(datata[,"mRNA_length"]-datata[,"exon_length"]), na.rm=TRUE)


features <- data.frame(values=c(snRNA, pre_miRNA, five_prime_UTR, three_prime_UTR, tRNA, miRNA, CDS, snoRNA, mRNA, exon, chromosome, pseudogene, ncRNA, intron), elements=c("snRNA", "pre_miRNA", "five_prime_UTR", "three_prime_UTR", "tRNA", "miRNA", "CDS", "snoRNA", "mRNA", "exon","chromosome", "pseudogene", "ncRNA", "intron") )
indel <- ggplot(data=features, aes(x=features$elements, y=features$values, fill=factor(elements))) + 
geom_bar(stat = "identity")+labs(x="", y="(allele frequency) / (sequence length)", fill="", title="INDEL distribution") + 
theme_bw() +theme_grey(base_size = 20) + theme(axis.line = element_line(colour = "black"),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
	axis.text.x = element_text(angle=300, hjust=0, vjust=1))

CairoPDF("indel.pdf", width=18, height=9)
indel
dev.off()


CairoPNG("indel.png",width=1200,height=600)
indel
dev.off()




datata <- read.table("fruitFly.table", head=TRUE)
datata=datata[which(datata$chromosome=="3R" | datata$chromosome=="3L"  |  datata$chromosome=="2R" |  datata$chromosome=="2L" | datata$chromosome=="4" | datata$chromosome=="X" ),]

snRNA <- mean(datata[,"snRNA_snpNo"]/datata[,"snRNA_length"], na.rm=TRUE)
pre_miRNA <- mean(datata[,"pre_miRNA_snpNo"]/datata[,"pre_miRNA_length"], na.rm=TRUE)
gene <- mean(datata[,"gene_snpNo"]/datata[,"gene_length"], na.rm=TRUE)
five_prime_UTR <- mean(datata[,"X5UTR_snpNo"]/datata[,"X5UTR_length"], na.rm=TRUE)
three_prime_UTR <- mean(datata[,"X3UTR_snpNo"]/datata[,"X3UTR_length"], na.rm=TRUE)
tRNA <- mean(datata[,"tRNA_snpNo"]/datata[,"tRNA_length"], na.rm=TRUE)
miRNA <- mean(datata[,"miRNA_snpNo"]/datata[,"miRNA_length"], na.rm=TRUE)
CDS <- mean(datata[,"CDS_snpNo"]/datata[,"CDS_length"], na.rm=TRUE)
snoRNA <- mean(datata[,"snoRNA_snpNo"]/datata[,"snoRNA_length"], na.rm=TRUE)
mRNA <- mean(datata[,"mRNA_snpNo"]/datata[,"mRNA_length"], na.rm=TRUE)
exon <- mean(datata[,"exon_snpNo"]/datata[,"exon_length"], na.rm=TRUE)
chromosome <- mean(datata[,"chromesome_snpNo"]/datata[,"chromesome_length"], na.rm=TRUE)
pseudogene <- mean(datata[,"pseudogene_snpNo"]/datata[,"pseudogene_length"], na.rm=TRUE)
ncRNA <- mean(datata[,"ncRNA_snpNo"]/datata[,"ncRNA_length"], na.rm=TRUE)
intron <- mean((datata[,"mRNA_snpNo"]-datata[,"CDS_snpNo"])/(datata[,"mRNA_length"]-datata[,"CDS_length"]), na.rm=TRUE)


features <- data.frame(values=c(snRNA, pre_miRNA, five_prime_UTR, three_prime_UTR, tRNA, miRNA, CDS, snoRNA, mRNA, exon, chromosome, pseudogene, ncRNA, intron), elements=c("snRNA", "pre_miRNA","five_prime_UTR", "three_prime_UTR", "tRNA", "miRNA", "CDS", "snoRNA", "mRNA", "exon","chromosome", "pseudogene", "ncRNA", "intron") )
snp <- ggplot(data=features, aes(x=features$elements, y=features$values, fill=factor(elements))) + 
geom_bar(stat = "identity")+labs(x="", y="(allele frequency) / (sequence length)", fill="", title="SNP distribution") + 
theme_bw() +theme_grey(base_size = 20) + theme(axis.line = element_line(colour = "black"),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
	axis.text.x = element_text(angle=300, hjust=0, vjust=1))

snp
CairoPDF("snp.pdf", width=18, height=9)
snp
dev.off()


CairoPNG("snp.png",width=1200,height=600)
snp
dev.off()




data2 <- datata
#data2 <- data2[-which(data2[,"CDS_indelNo"] == 0),]
data2$cdsRatio <- data2[,"CDS_indelNo"] / data2[,"CDS_snpNo"]
data2$wholeGenomeRatio <- data2[,"chromesome_indelNo"] / data2[,"chromesome_snpNo"]

wilcox.test(data2$cdsRatio, data2$wholeGenomeRatio, paired =T)


# 	Wilcoxon signed rank test with continuity correction

# data:  data2$cdsRatio and data2$wholeGenomeRatio
# V = 557040, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0



data3 <- data.frame(factor="fruitFly_Genome",distance=data2$wholeGenomeRatio, color="A")
data3=rbind(data3, data.frame(factor="fruitFly_CDS",distance=data2$cdsRatio, color="A"))

data4 <- read.table("StatisticsMutationRegion.table", head=TRUE)
data4$cdsRatio <- data4[,"CDS_indelNo"] / data4[,"CDS_snpNo"]
data4$wholeGenomeRatio <- data4[,"chromosome_indelNo"] / data4[,"chromosome_snpNo"]
data3=rbind(data3, data.frame(factor="ath_Genome",distance=data4$wholeGenomeRatio, color="B"))
data3=rbind(data3, data.frame(factor="ath_CDS",distance=data4$cdsRatio, color="B"))


plot <- ggplot(data=data3)+geom_boxplot(aes(factor, distance),outlier.colour="#FFFFFF")+geom_point( position = position_jitter(width = 0.618),aes(factor, distance, color=color) )+
    labs( y="INDEL/SNP ratio", x="", color="", fill="", title="") +theme_bw() +theme_grey(base_size = 25) + theme(axis.line = element_line(colour = "black"),legend.position = "none",
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(fill=NA, color="black", size=0.5, linetype="solid"),
    panel.background = element_blank(),
    axis.text.x = element_text(angle=285, hjust=0, vjust=1))


CairoPDF("plot.pdf", width=9, height=6)
plot
dev.off()


CairoPNG("plot.png",width=600,height=400)
plot
dev.off()





# ===
# ggplot(data=data2, aes(x=wholeGenomeRatio))+geom_density(aes(fill="Genome"))+geom_density(aes(x=cdsRatio, fill="CDS"))+
# labs(x="SNP/INDEL ratio", y="Density", fill="", title="")+
# theme_bw()+theme_grey(base_size = 30) +theme(axis.line = element_line(colour = "black"),
#     panel.grid.major = element_blank(),
#     panel.grid.minor = element_blank(),
#     panel.border = element_blank(),
#     panel.background = element_blank())+
# theme(legend.position = c(.75, .8))