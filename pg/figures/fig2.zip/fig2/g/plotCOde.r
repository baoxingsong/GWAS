library(ggplot2)
library(reshape)
library("heatmap3")
library(reshape2)
library(gdata)
library("Cairo")
library(RColorBrewer)
data <- read.table("fruitFly", row.names = 1)
row.names(data) <- gsub("(\\.CSV)$", "", row.names(data), perl=TRUE)
row.names(data) <- gsub("(\\.csv)$", "", row.names(data), perl=TRUE)
data2=data[which(data[,7]>0.001),]

data10 <- read.table("./map", row.names = 1)

data2<-data2[,-2]
data2<-data2[,-2]
data2<-data2[,-3]
data2<-data2[,-3]


data2$V8=data2$V8-data2$V5
data2$V5=data2$V5-data2$V2

row.names(data2) <- data10[row.names(data2),]$V2
#row.names(data2) <- paste("fly", row.names(data2), sep="_")
row.names(data2) <- gsub("(female)$", "f", row.names(data2), perl=TRUE)
row.names(data2) <- gsub("(male)$", "m", row.names(data2), perl=TRUE)
dataf=data2

table=read.table("./phenotype_published_raw.csv", sep="\t", head=TRUE)
matrix  <- as.matrix(table)
matrix2 <- t(matrix)
row.names(matrix2) <- sub("(X\\d+_)", "", row.names(matrix2), perl=TRUE)
row.names(matrix2) <- gsub("(\\.i\\.)", "", row.names(matrix2), perl=TRUE)
row.names(matrix2) <- gsub("^(\\.)", "", row.names(matrix2), perl=TRUE)
row.names(matrix2) <- gsub("(\\.)$", "", row.names(matrix2), perl=TRUE)
data <- read.table("ath")

rownames(data) <- row.names(matrix2)[data$V1+1]
#rownames(data)=paste("a.th", row.names(data), sep="_")
data=data[which(data[,8]>0.001),]
data2<-data[,-1]
data2<-data2[,-2]
data2<-data2[,-2]
data2<-data2[,-3]
data2<-data2[,-3]


data2$V8=data2$V8-data2$V5
data2$V5=data2$V5-data2$V2

colnames(data2) = c("V3", "V4", "V5")
colnames(dataf) = c("V3", "V4", "V5")



data2 <- rbind(data2, dataf)


matrix  <- as.matrix(data2)
matrix2 <- t(matrix)
data3 <- as.data.frame(matrix2, header = TRUE)
data4 <- melt(data3)
row <- rep(1:3, length=nrow(data4))
row[which (row==1)] = "explained variance by SNP"
row[which (row==2)] = "additional explained variance by INDEL"
row[which (row==3)] = "additional explained variance by ORFS"

row <- as.factor(row)
ccc <- c("additional explained variance by ORFS", "additional explained variance by INDEL", "explained variance by SNP")

row <- factor(row, levels = ccc)
df <- cbind(data4, row)

myColors <- brewer.pal(3,"Set1")
myColors=rev(myColors)
names(myColors) <- factor(ccc, levels = ccc)

colScale1 <- scale_color_manual(name = "row",values = myColors)

myColors2 <- brewer.pal(3,"Set1")
myColors2=rev(myColors2)
names(myColors2) <- factor(ccc, levels = ccc)
colScale2 <- scale_fill_manual(name = "row",values = myColors2)


plot <- ggplot(df, aes(x=variable, y=value, fill=row, color=row)) + geom_bar(stat="identity")+colScale1+colScale2 + xlab("") + 
	ylab("explained phenotype variance")+guides(fill = guide_legend(title=""), color=FALSE)+theme_grey(base_size = 38)+
	theme(
	axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, color=c(rep("darkorange3",34),rep("blue",24))),
 	legend.position="top",
 	legend.direction="horizontal",
 	panel.border = element_rect(colour = "black", fill=NA),
	panel.grid.major = element_blank(),
	panel.grid.minor = element_blank(),
	panel.background = element_blank(),
	axis.text.y=element_text(color="black")
	)

png("proporation_have_sig_h.png", width=2000, height=1200)
plot
dev.off()

pdf("proporation_have_sig_h.pdf", width=30, height=18)
plot
dev.off()






