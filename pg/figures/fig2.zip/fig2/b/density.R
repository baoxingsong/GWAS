library(ggplot2)
library(scales)
library(RColorBrewer)

data <- read.table("fruitFly", head=TRUE)
data$species="fruit fly"
data2 <- read.table("ath", head=TRUE)
data2$species="Arabidopsis thaliana"



corValue = cor(data$IndelDensity,data$SnpDensity, method="kendall")
corValue <- paste("τ==", round(corValue,3))

corValue2 = cor(data2$IndelDensity,data2$SnpDensity, method="kendall")
corValue2 <- paste("τ==", round(corValue2,3))

#eruption.lm = lm(IndelDensity ~ SnpDensity, data=data)
#corValue <- paste("r^2==", round(summary(eruption.lm)$r.squared,2))

#eruption.lm2 = lm(IndelDensity ~ SnpDensity, data=data2)
#corValue2 <- paste("r^2==", round(summary(eruption.lm2)$r.squared,2))


p <- 

ggplot()+ geom_smooth(data=data, aes(IndelDensity, SnpDensity, color=species), method = "lm") +  annotate("text", label=corValue, color="turquoise3", x=500, y=14000, size=12, parse=TRUE) + geom_point(data=data, aes(IndelDensity, SnpDensity, color=species))+
geom_smooth(data=data2, aes(IndelDensity, SnpDensity, color=species), method = "lm") +  annotate("text", label=corValue2, color="red", x=500, y=12000, size=12, parse=TRUE) + geom_point(data=data2, aes(IndelDensity, SnpDensity, color=species)) +scale_color_discrete(guide = guide_legend(title = ""))+
theme_bw()+theme_grey(base_size = 25) +labs(x="INDEL density",  y="SNP density")+ theme(
	panel.border = element_rect(colour = "black", fill=NA,size=1),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
	legend.text=element_text(size=22),
	strip.background = element_blank(),
    panel.background = element_blank(),
	strip.text.x=element_text(angle=0,hjust=0, vjust=0),
	axis.text.x=element_text(color="black"),
	axis.text.y=element_text(color="black"),
	legend.position = c(.7, .12))

png("correlation.png",width=600,height=400)
print(p)
dev.off()
pdf(file="correlation.pdf", width=9, height=6)
print(p)
dev.off()


cor.test(data$IndelDensity,data$SnpDensity, method="kendall")

	Kendall's rank correlation tau

data:  data$IndelDensity and data$SnpDensity
z = 18.437, p-value < 2.2e-16
alternative hypothesis: true tau is not equal to 0
sample estimates:
    tau 
0.75038 

cor.test(data2$IndelDensity,data2$SnpDensity, method="kendall")

	Kendall's rank correlation tau

data:  data2$IndelDensity and data2$SnpDensity
z = 18.351, p-value < 2.2e-16
alternative hypothesis: true tau is not equal to 0
sample estimates:
      tau 
0.7956614

